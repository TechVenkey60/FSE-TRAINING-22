package com.awd.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwsSpringBootAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwsSpringBootAppApplication.class, args);
	}

}
