package com.jwt.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJwtRoleBasedSecurityAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJwtRoleBasedSecurityAppApplication.class, args);
	}

}
