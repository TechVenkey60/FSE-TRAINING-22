package com.employment.demo.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MircoServiceEmploymentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
